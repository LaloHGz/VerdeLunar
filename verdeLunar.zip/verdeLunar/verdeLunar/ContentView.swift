//
//  ContentView.swift
//  VerdeLunar
//
//  Created by Alumno on 09/03/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Login()
    }
}

#Preview {
    ContentView()
}
